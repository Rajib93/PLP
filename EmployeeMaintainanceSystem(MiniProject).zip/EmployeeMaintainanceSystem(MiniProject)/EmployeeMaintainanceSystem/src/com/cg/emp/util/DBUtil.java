/*package com.cg.emp.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import oracle.jdbc.pool.OracleDataSource;

public class DBUtil {

	public static Connection getConnection() throws SQLException {
		OracleDataSource ods=new OracleDataSource();

		ods.setUser("Labg103trg21");

		ods.setPassword("labg103oracle");

		ods.setDriverType("thin");

		ods.setNetworkProtocol("tcp");

		ods.setURL("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g");
		
		System.out.println(ods);

		return ods.getConnection();
		 
		InitialContext ic;
		DataSource ds;
		Connection con = null;
		try {
			ic = new InitialContext();
			ds = (DataSource) ic.lookup("java:/jdbc/SaruVarma");
			con = ds.getConnection();
		} catch (NamingException e) {

			e.printStackTrace();
		}

		
	}
}
*/




package com.cg.emp.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.emp.exception.EmployeeException;







/**
 * Author 		: CAPGEMINI 
 * Class Name 	: DbConnection
 * Package 		: com.cg.mc.util
 * Date 		: April 10,2017
 */

public class DBUtil {
	public static Connection getConnection() throws EmployeeException {
		Connection conn = null;

		try {
			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource) ic.lookup("java:/jdbc/SaruVarma");
			conn = ds.getConnection();
		}

		catch (SQLException e) {
			throw new EmployeeException("SQL Error:"+e.getMessage());
		} catch (NamingException e) {
			throw new EmployeeException("message from DB/NamingExc:"
					+ e.getMessage());
		}
		return conn;
	}
}
