package com.cg.emp.service;


import java.sql.SQLException;
import java.util.List;

import com.cg.emp.dao.EmployeeDao;
import com.cg.emp.dao.EmployeeDaoImpl;
import com.cg.emp.dto.Employee;
import com.cg.emp.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService{
	EmployeeDao empDao = null;
	public EmployeeServiceImpl() throws EmployeeException {
		empDao = new EmployeeDaoImpl();
	}
	//Start Of Add Employee
	@Override
	public int addEmployeeDetails(Employee emp) throws EmployeeException {
		
			int status=empDao.addEmployeeDetails(emp);
			return status;

		}

	
	//Start Of Show All
	@Override
	public List<Employee> showAll() throws EmployeeException, SQLException {
		
			List<Employee> empList=empDao.showAll();
			return empList;
	}
	

	@Override
	public int isValid(String userName, String userPassword)
			throws EmployeeException {
		
			int data=empDao.isValid(userName, userPassword);
			return data;
		
	}
	@Override
	public Employee searchEmployeeOnId(String EmpId) throws EmployeeException {
	
			Employee emp=empDao.searchEmployeeOnId(EmpId);
			return emp;
		
		}

	@Override
	public List<Employee> searchEmployeeOnFirstName(String firstName)
			throws EmployeeException {
	
			List<Employee> empFirstNameList=empDao.searchEmployeeOnFirstName(firstName);
			return empFirstNameList;
		
	}
	@Override
	public List<Employee> searchEmployeeOnLastName(String lastName)
			throws EmployeeException {
		
			List<Employee> empLastNameList=empDao.searchEmployeeOnLastName(lastName);
			return empLastNameList;
		
	}
	@Override
	public List<Employee> searchEmployeeOnMaritalStatus(String status1, String status2, String status3, String status4, String status5)
			throws EmployeeException {
	
			List<Employee> empMaritalList=empDao.searchEmployeeOnMaritalStatus(status1, status2, status3, status4, status5);
			return empMaritalList;
	
		}
	
	@Override
	public void updateEmployee(Employee emp) throws EmployeeException {
	
			empDao.updateEmployee(emp);
		
			}
	@Override
	public List<Employee> searchEmployeeOnDepartment(String empDept1,
			String empDept2, String empDept3, String empDept4, String empDept5,
			String empDept6) throws EmployeeException {
		
		return empDao.searchEmployeeOnDepartment(empDept1, empDept2, empDept3, empDept4, empDept5, empDept6);
	}
	@Override
	public List<Employee> searchEmployeeOnGrade(String grade1, String grade2,
			String grade3, String grade4, String grade5, String grade6,
			String grade7) throws EmployeeException {
		
		return empDao.searchEmployeeOnGrade(grade1, grade2, grade3, grade4, grade5, grade6, grade7);
	}
	

	
}
