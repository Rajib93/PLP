package com.capgemini.employeemaintenance.dto;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Grade {
	@Id
	private String gradeCode;
	private String gradeDescription;
	private int gradeMinSalary;
	private int gradeMaxsalary;
	@OneToMany(mappedBy="grade",cascade=CascadeType.ALL)
	private Set<Employee> empSet=new HashSet<>();
	
	
	
	public String getGradeCode() {
		return gradeCode;
	}
	public void setGradeCode(String gradeCode) {
		this.gradeCode = gradeCode;
	}
	public String getGradeDescription() {
		return gradeDescription;
	}
	public void setGradeDescription(String gradeDescription) {
		this.gradeDescription = gradeDescription;
	}
	public int getGradeMinSalary() {
		return gradeMinSalary;
	}
	public void setGradeMinSalary(int gradeMinSalary) {
		this.gradeMinSalary = gradeMinSalary;
	}
	public int getGradeMaxsalary() {
		return gradeMaxsalary;
	}
	public void setGradeMaxsalary(int gradeMaxsalary) {
		this.gradeMaxsalary = gradeMaxsalary;
	}
	public Set<Employee> getEmpSet() {
		return empSet;
	}
	public void setEmpSet(Set<Employee> empSet) {
		this.empSet = empSet;
	}
	
}
