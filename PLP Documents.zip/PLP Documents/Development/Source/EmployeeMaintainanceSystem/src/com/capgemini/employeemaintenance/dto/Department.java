package com.capgemini.employeemaintenance.dto;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class Department {
	@Id
	
	private int deptId;
	private String deptName;
	@OneToMany(mappedBy="department",cascade=CascadeType.ALL)
	private Set<Employee> empSet=new HashSet<>();
	
	
	
	public Set<Employee> getEmpSet() {
		return empSet;
	}
	public void setEmpSet(Set<Employee> empSet) {
		this.empSet = empSet;
	}
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
/*	public void addEmployee(Employee employeeBean) {
		employeeBean.setDepartment(this);			
	
		Set<Employee> empSet=getEmpSet();
		empSet.add(employeeBean);
	}*/
	
	
}
