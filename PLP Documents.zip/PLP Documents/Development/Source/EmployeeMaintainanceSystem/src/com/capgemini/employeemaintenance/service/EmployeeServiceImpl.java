package com.capgemini.employeemaintenance.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.employeemaintenance.dao.IEmployeeDao;
import com.capgemini.employeemaintenance.dto.Employee;
import com.capgemini.employeemaintenance.exception.EmployeeException;

@Service
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	private IEmployeeDao employeeDao;

	@Override
	public Employee addEmployee(Employee employeeBean) throws EmployeeException {
		return employeeDao.addEmployee(employeeBean);
	}

	@Override
	public int isValid(String userName, String password)
			throws EmployeeException {

		return employeeDao.isValid(userName, password);
	}

	@Override
	public List<Employee> viewAllEmployee() throws EmployeeException {

		return employeeDao.viewAllEmployee();
	}

}
