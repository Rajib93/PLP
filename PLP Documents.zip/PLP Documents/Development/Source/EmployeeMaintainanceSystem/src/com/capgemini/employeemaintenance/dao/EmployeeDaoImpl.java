package com.capgemini.employeemaintenance.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.employeemaintenance.dto.Employee;
import com.capgemini.employeemaintenance.dto.UserMaster;
import com.capgemini.employeemaintenance.exception.EmployeeException;

@Repository
@Transactional
public class EmployeeDaoImpl implements IEmployeeDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Employee addEmployee(Employee employeeBean) throws EmployeeException {
		entityManager.persist(employeeBean);
		entityManager.flush();
		return employeeBean;
	}

	@Override
	public int isValid(String userName, String password)
			throws EmployeeException {
		try {
			TypedQuery<UserMaster> query = entityManager.createQuery(
					"select u from UserMaster u where userName is :userName",
					UserMaster.class);

			query.setParameter("userName", userName);
			UserMaster user = (UserMaster) query.getSingleResult();

			if (user.getUserType().equals("admin")) {
				if (user.getUserPassword().equals(password)) {
					return 1;
				}

			} else if (user.getUserType().equals("employee")) {
				if (user.getUserPassword().equals(password)) {
					return 2;
				}

			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return 0;
	}

	@Override
	public List<Employee> viewAllEmployee() throws EmployeeException {
		TypedQuery<Employee> query = entityManager.createQuery(
				"SELECT e FROM Employee e", Employee.class);
		return query.getResultList();
	}

}
