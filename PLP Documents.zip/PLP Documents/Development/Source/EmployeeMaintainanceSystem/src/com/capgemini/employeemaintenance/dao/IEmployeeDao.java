package com.capgemini.employeemaintenance.dao;

import java.util.List;

import com.capgemini.employeemaintenance.dto.Employee;
import com.capgemini.employeemaintenance.exception.EmployeeException;

public interface IEmployeeDao {

	public Employee addEmployee(Employee employeeBean) throws EmployeeException;

	public int isValid(String userName, String password)
			throws EmployeeException;

	public List<Employee> viewAllEmployee() throws EmployeeException;
}
