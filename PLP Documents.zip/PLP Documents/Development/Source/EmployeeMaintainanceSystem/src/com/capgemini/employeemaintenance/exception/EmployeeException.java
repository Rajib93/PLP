package com.capgemini.employeemaintenance.exception;

public class EmployeeException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 9084325477254092541L;

	public EmployeeException(String message) {
		super(message);
		
	}
	

}
