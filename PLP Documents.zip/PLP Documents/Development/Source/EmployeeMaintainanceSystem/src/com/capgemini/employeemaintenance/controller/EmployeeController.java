package com.capgemini.employeemaintenance.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.employeemaintenance.dto.Employee;
import com.capgemini.employeemaintenance.exception.EmployeeException;
import com.capgemini.employeemaintenance.service.IEmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	private IEmployeeService employeeService;

	@RequestMapping("login")
	public String homepage() {

		return "home";
	}

	@RequestMapping("authenticate")
	public ModelAndView login(@RequestParam("userName") String userName,
			@RequestParam("password") String password) {

		ModelAndView modelAndView = new ModelAndView();

		try {
			int result;
			result = employeeService.isValid(userName, password);

			if (result == 1) {
				modelAndView.setViewName("admin");
			} else if (result == 2) {
				modelAndView.setViewName("employee");
			} else {
				modelAndView.setViewName("login");

			}
		} catch (EmployeeException e) {
			System.out.println(e.getMessage());
			// logger.error("Enter correct Login Credentials",e);
		}
		return modelAndView;
	}

	@RequestMapping("addEmployee")
	public String addEmployee() {
		return "addEmployee";
	}

	@RequestMapping("addSuccess")
	public ModelAndView addSuccess(
			@ModelAttribute("employeeBean") Employee employeeBean) {

		ModelAndView modelAndView = new ModelAndView();

		try {

			employeeBean = employeeService.addEmployee(employeeBean);

			modelAndView = new ModelAndView("added");
			modelAndView.addObject("employeeBean", employeeBean);

		} catch (EmployeeException e) {
			String msg = "Adding Employee Failed";
			modelAndView.setViewName("error");
			modelAndView.addObject("msg", msg);
		}

		return modelAndView;
	}

	@RequestMapping("getEmployeeId")
	public String getEmployeeId() {
		return "getEmployeeId";
	}

	@RequestMapping("viewAllEmp")
	public ModelAndView viewAllEmp() {
		ModelAndView modelAndView = new ModelAndView();

		List<Employee> list;
		try {
			list = employeeService.viewAllEmployee();

			if (list.isEmpty()) {
				String msg = "There are no Employees";
				modelAndView.setViewName("error");
				modelAndView.addObject("msg", msg);
			} else {
				modelAndView.setViewName("viewAllEmp");

				modelAndView.addObject("list", list);
			}
		} catch (EmployeeException e) {
			String msg = "Error in displaying Employees";
			modelAndView.setViewName("error");
			modelAndView.addObject("msg", msg);
		}
		return modelAndView;

	}

}
