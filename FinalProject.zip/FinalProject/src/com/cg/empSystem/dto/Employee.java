package com.cg.empSystem.dto;

import java.sql.Date;

public class Employee {
	
	private String empId;
	private String empFname;
	private String empLname;
	private Date empDateOfBirth;
	private Date empDateOfJoining;
	private int empDeptId;
	private String empGrade;
	private String empDesignation;
	private int empBasic;
	private String empGender;
	private String empMaritalStatus;
	private String empHomeAddress;
	private String empContactNo;
	private Department dept;
	private Grade grade;
	
	public Employee() {
	}

	//this constructor have emp and grade data
	public Employee(String empId, String empFname, String empLname,
			Date empDateOfBirth, Date empDateOfJoining, int empDeptId,
			String empGrade, String empDesignation, int empBasic,
			String empGender, String empMaritalStatus, String empHomeAddress,
			String empContactNo, Grade grade) {
		super();
		this.empId = empId;
		this.empFname = empFname;
		this.empLname = empLname;
		this.empDateOfBirth = empDateOfBirth;
		this.empDateOfJoining = empDateOfJoining;
		this.empDeptId = empDeptId;
		this.empGrade = empGrade;
		this.empDesignation = empDesignation;
		this.empBasic = empBasic;
		this.empGender = empGender;
		this.empMaritalStatus = empMaritalStatus;
		this.empHomeAddress = empHomeAddress;
		this.empContactNo = empContactNo;
		this.grade = grade;
	}


	//this constructor have employee and department data
	
	public Employee(String empId, String empFname, String empLname,
			Date empDateOfBirth, Date empDateOfJoining, int empDeptId,
			String empGrade, String empDesignation, int empBasic,
			String empGender, String empMaritalStatus, String empHomeAddress,
			String empContactNo, Department dept) {
		super();
		this.empId = empId;
		this.empFname = empFname;
		this.empLname = empLname;
		this.empDateOfBirth = empDateOfBirth;
		this.empDateOfJoining = empDateOfJoining;
		this.empDeptId = empDeptId;
		this.empGrade = empGrade;
		this.empDesignation = empDesignation;
		this.empBasic = empBasic;
		this.empGender = empGender;
		this.empMaritalStatus = empMaritalStatus;
		this.empHomeAddress = empHomeAddress;
		this.empContactNo = empContactNo;
		this.dept = dept;
	}

	//this constructor have emp data
	public Employee(String empId, String empFname, String empLname,
			Date empDateOfBirth, Date empDateOfJoining, int empDeptId,
			String empGrade, String empDesignation, int empBasic,
			String empGender, String empMaritalStatus, String empHomeAddress,
			String empContactNo) {
		super();
		this.empId = empId;
		this.empFname = empFname;
		this.empLname = empLname;
		this.empDateOfBirth = empDateOfBirth;
		this.empDateOfJoining = empDateOfJoining;
		this.empDeptId = empDeptId;
		this.empGrade = empGrade;
		this.empDesignation = empDesignation;
		this.empBasic = empBasic;
		this.empGender = empGender;
		this.empMaritalStatus = empMaritalStatus;
		this.empHomeAddress = empHomeAddress;
		this.empContactNo = empContactNo;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpFname() {
		return empFname;
	}

	public void setEmpFname(String empFname) {
		this.empFname = empFname;
	}

	public String getEmpLname() {
		return empLname;
	}

	public void setEmpLname(String empLname) {
		this.empLname = empLname;
	}

	public Date getEmpDateOfBirth() {
		return empDateOfBirth;
	}

	public void setEmpDateOfBirth(Date empDateOfBirth) {
		this.empDateOfBirth = empDateOfBirth;
	}

	public Date getEmpDateOfJoining() {
		return empDateOfJoining;
	}

	public void setEmpDateOfJoining(Date empDateOfJoining) {
		this.empDateOfJoining = empDateOfJoining;
	}

	public int getEmpDeptId() {
		return empDeptId;
	}

	public void setEmpDeptId(int empDeptId) {
		this.empDeptId = empDeptId;
	}

	public String getEmpGrade() {
		return empGrade;
	}

	public void setEmpGrade(String empGrade) {
		this.empGrade = empGrade;
	}

	public String getEmpDesignation() {
		return empDesignation;
	}

	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}

	public int getEmpBasic() {
		return empBasic;
	}

	public void setEmpBasic(int empBasic) {
		this.empBasic = empBasic;
	}

	public String getEmpGender() {
		return empGender;
	}

	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}

	public String getEmpMaritalStatus() {
		return empMaritalStatus;
	}

	public void setEmpMaritalStatus(String empMaritalStatus) {
		this.empMaritalStatus = empMaritalStatus;
	}

	public String getEmpHomeAddress() {
		return empHomeAddress;
	}

	public void setEmpHomeAddress(String empHomeAddress) {
		this.empHomeAddress = empHomeAddress;
	}

	public String getEmpContactNo() {
		return empContactNo;
	}

	public void setEmpContactNo(String empContactNo) {
		this.empContactNo = empContactNo;
	}

	
	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}

	public Grade getGrade() {
		return grade;
	}

	public void setGrade(Grade grade) {
		this.grade = grade;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empFname=" + empFname
				+ ", empLname=" + empLname + ", empDateOfBirth="
				+ empDateOfBirth + ", empDateOfJoining=" + empDateOfJoining
				+ ", empDeptId=" + empDeptId + ", empGrade=" + empGrade
				+ ", empDesignation=" + empDesignation + ", empBasic="
				+ empBasic + ", empGender=" + empGender + ", empMaritalStatus="
				+ empMaritalStatus + ", empHomeAddress=" + empHomeAddress
				+ ", empContactNo=" + empContactNo + ", dept=" + dept
				+ ", grade=" + grade + "]";
	}
	
	
}
