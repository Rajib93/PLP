package com.cg.emp.service;


import java.sql.SQLException;
import java.util.List;

import com.cg.emp.dao.EmployeeDao;
import com.cg.emp.dao.EmployeeDaoImpl;
import com.cg.emp.dto.Employee;
import com.cg.emp.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService{
	EmployeeDao empDao = null;
	public EmployeeServiceImpl() throws EmployeeException {
		empDao = new EmployeeDaoImpl();
	}
	//Start Of Add Employee
	@Override
	public int addEmployeeDetails(Employee emp) throws EmployeeException {
		try {
			int status=empDao.addEmployeeDetails(emp);
			return status;
		} catch (EmployeeException e) {
			throw new EmployeeException("Insertion Can not Be Done On Database!!!!!!!");
		}
		
	}// End Of Add Employee
	
	// Start of Remove Employee
	

	
	//Start Of Show All
	@Override
	public List<Employee> showAll() throws EmployeeException, SQLException {
		try {
			List<Employee> empList=empDao.showAll();
			return empList;
		} catch (EmployeeException e) {
		throw new EmployeeException("Data Can't Retrieved From Database!!!!!!");
		}
	}//End Of Show All
	
	//Start Of Valid Login
	@Override
	public int isValid(String userName, String userPassword)
			throws EmployeeException {
		try {
			int data=empDao.isValid(userName, userPassword);
			return data;
		} catch (EmployeeException e) {
			throw new EmployeeException("Login Can't be Done!!!!!!!!");
		}
	}//End Of Valid login
	
	//Start Of Search Employee On Id
	@Override
	public Employee searchEmployeeOnId(String EmpId) throws EmployeeException {
		try {
			Employee emp=empDao.searchEmployeeOnId(EmpId);
			return emp;
		} catch (EmployeeException e) {
			throw new EmployeeException("Search Can't Be Done On Basis Of Your Employee Id!!!!!!!");
		}
	
	}//End of Search Employee On Id
	
	//Start of Search Employee on First name
	@Override
	public List<Employee> searchEmployeeOnFirstName(String firstName)
			throws EmployeeException {
		try {
			List<Employee> empFirstNameList=empDao.searchEmployeeOnFirstName(firstName);
			return empFirstNameList;
		} catch (EmployeeException e) {
			throw new EmployeeException("Search Can't be Done On Basis Of Your Entered First Name!!!!!!!!");
		}
	}//End of Search Employee on First name
	
	//Start of Search Employee on Last name
	@Override
	public List<Employee> searchEmployeeOnLastName(String lastName)
			throws EmployeeException {
		try {
			List<Employee> empLastNameList=empDao.searchEmployeeOnLastName(lastName);
			return empLastNameList;
		} catch (EmployeeException e) {
			throw new EmployeeException("Search Can't be Done On Basis Of Your Entered Last Name!!!!!!!!");
		}
	}//End of Search Employee on last name
	
/*	//Start Of Search Employee on Department name
	@Override
	public List<Employee> searchEmployeeOnDepartment(String deptName)
			throws EmployeeException {
		try {
			List<Employee> empDeptAndEmpList=empDao.searchEmployeeOnDepartment(deptName);
			return empDeptAndEmpList;
		} catch (EmployeeException e) {
			throw new EmployeeException("Search Can't be Done On Basis Of Your Selected Department Names!!!!!!!!");
		}
	}//End Of Search Employee on Last name
*/	
	//Start of Search Employee on Grade
	/*@Override
	public List<Employee> searchEmployeeOnGrade(String grade)
			throws EmployeeException {
		try {
			List<Employee> empGradeAndEmpList=empDao.searchEmployeeOnGrade(grade);
			return empGradeAndEmpList;
		} catch (EmployeeException e) {
			throw new EmployeeException("Search Can't be Done On Basis Of Your Selected Grades!!!!!!!!");
		}
	}*///End of Search Employee on Grade
	
	//Start of Search Employee on Marital Status
	@Override
	public List<Employee> searchEmployeeOnMaritalStatus(String status1, String status2, String status3, String status4, String status5)
			throws EmployeeException {
		try {
			List<Employee> empMaritalList=empDao.searchEmployeeOnMaritalStatus(status1, status2, status3, status4, status5);
			return empMaritalList;
		} catch (EmployeeException e) {
			throw new EmployeeException("Search Can't be Done On Basis Of Your Selected Marital Status!!!!!!!!");
		}
	}//End Of Search Employee on Marital Status
	
	
	//Start of update employee
	@Override
	public Employee updateEmployee(Employee emp) throws EmployeeException {
		try {
			Employee employee=empDao.updateEmployee(emp);
			
			return employee;
		} catch (EmployeeException e) {
			throw new EmployeeException("Update Can't be Done On Basis Of your Provided Data!!!!!!!!!!!!");
		}
	}//End of update employee
	@Override
	public List<Employee> searchEmployeeOnDepartment(String empDept1,
			String empDept2, String empDept3, String empDept4, String empDept5,
			String empDept6) throws EmployeeException {
		// TODO Auto-generated method stub
		return empDao.searchEmployeeOnDepartment(empDept1, empDept2, empDept3, empDept4, empDept5, empDept6);
	}
	@Override
	public List<Employee> searchEmployeeOnGrade(String grade1, String grade2,
			String grade3, String grade4, String grade5, String grade6,
			String grade7) throws EmployeeException {
		
		return empDao.searchEmployeeOnGrade(grade1, grade2, grade3, grade4, grade5, grade6, grade7);
	}
	

	
}
