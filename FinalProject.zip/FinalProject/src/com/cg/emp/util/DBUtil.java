package com.cg.emp.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBUtil {

	public static Connection getConnection() throws SQLException {

		/*
		 * OracleDataSource ods= new OracleDataSource();
		 * ods.setUser("system"); ods.setPassword("admin");
		 * ods.setDriverType("thin"); ods.setNetworkProtocol("tcp");
		 * ods.setURL("jdbc:oracle:thin:@localhost:1521:XE");
		 */
		InitialContext ic;
		DataSource ds;
		Connection con = null;
		try {
			ic = new InitialContext();
			ds = (DataSource) ic.lookup("java:/jdbc/OracleDS");
			con = ds.getConnection();
		} catch (NamingException e) {

			e.printStackTrace();
		}

		return con;
	}
}
